package com.TouristExample.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.TouristExample.model.PackageDetails;
import com.TouristExample.model.PlaceDetails;
import com.TouristExample.util.ConnectionPool;
@Configuration
public class PlaceAndPackageDao {
	
	@Autowired

	ConnectionPool connection;

	Logger logger = LogManager.getLogger(PlaceAndPackageDao.class);
	public java.util.List<PlaceDetails> placeAndPackege() {

		try {
			List list = new ArrayList();
			String placepackage = " exec PLCEPACKAGESELECT";

			PreparedStatement stmnt = connection.connect().prepareStatement(placepackage);
			ResultSet result = stmnt.executeQuery();
			if (result != null) {
				List<PlaceDetails> place = new ArrayList<PlaceDetails>();
				List<PackageDetails> Package = new ArrayList<PackageDetails>();		

				list.add(place);
				list.add(Package);

				while (result.next()) {
					PlaceDetails places = new PlaceDetails();
					PackageDetails pack = new PackageDetails();
					places.setPlaceId(result.getInt("placeId"));
					places.setPlacesName(result.getString("placeName"));
					pack.setPackageId(result.getInt("packageId"));
					pack.setPackageName(result.getString("packageName"));
					pack.setPackagePrice(result.getFloat("packagePrice"));
					pack.setPackageType(result.getInt("packageType"));
					pack.setPlaceId(result.getInt("placeId"));


					place.add(places);
					Package.add(pack);
				}
				logger.info("Success");

				return list;
			}
			logger.info("Try block enter");

		} catch (Exception e) {
			logger.fatal("Detail Retrieved Failed " + e.getLocalizedMessage());
		}
		return null;

	}

}
