package com.TouristExample.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.TouristExample.model.PackageDetails;
import com.TouristExample.model.PaymentDetails;
import com.TouristExample.model.PlaceDetails;
import com.TouristExample.model.UserDetails;
import com.TouristExample.util.ConnectionPool;

@Configuration
public class UserDao {
	@Autowired

	ConnectionPool connection;

	Logger logger = LogManager.getLogger(UserDao.class);

	public boolean newUser(long aadharNumber, long cardNumber, int pinNumber)

	{

		try {

			String str = "exec USERSINSERT @aadharNumber=?, @cardNumber=?,@pinNumber=?";

			PreparedStatement newuser = connection.connect().prepareStatement(str);
			newuser.setLong(1, aadharNumber);
			newuser.setLong(2, cardNumber);
			newuser.setInt(3, pinNumber);
			newuser.execute();
			logger.info("try enter");
			return true;

		} catch (Exception e) {
			e.printStackTrace();
			logger.fatal("Datas Insertion Failed " + e.getLocalizedMessage());
		}
		return false;
	}

	public String oldUser(long AadharNumber) {

		try {
			connection.configure();

			String str = "exec USERSSELECT ?";
			PreparedStatement olduser = connection.connect().prepareStatement(str);
			olduser.setLong(1, AadharNumber);
			long AAdharNumber = 0;

			ResultSet result = olduser.executeQuery();
			if (result != null) {

				while (result.next()) {
					AAdharNumber = result.getLong("aadharNumber");

				}
				String number = String.valueOf(AAdharNumber);
				return number;

			}
			logger.info("Try block Enter");

		} catch (Exception e) {
			logger.fatal("Data Retrieved  Failed " + e.getLocalizedMessage());
			logger.info("Catch block Enter");


		}
		return null;

	}

	
	
}