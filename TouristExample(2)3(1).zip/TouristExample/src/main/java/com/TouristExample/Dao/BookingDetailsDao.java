package com.TouristExample.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.TouristExample.model.PaymentDetails;
import com.TouristExample.model.PlaceDetails;
import com.TouristExample.model.UserDetails;
import com.TouristExample.util.ConnectionPool;
@Configuration
public class BookingDetailsDao {
	@Autowired

	ConnectionPool connection;

	Logger logger = LogManager.getLogger(BookingDetailsDao.class);
	public boolean insertBookingDetails(int userId, int placeId, int memberCount,
			int paymentDetailsId, int bookingCode) throws SQLException {
		// TODO Auto-generated method stub
		try {

			String str = "exec BOOKINGINSERT @userId=?,@placeId=?,@memberCount=?,@paymentDetailsId=?,@bookingCode=?";
//			String str = "exec BOOKINGINSERT 101,401,3,701,5869";
			PreparedStatement booking = connection.connect().prepareStatement(str);
			booking.setInt(1, userId);
			booking.setInt(2, placeId);
			booking.setInt(3, memberCount);
			booking.setInt(4, paymentDetailsId);
			booking.setInt(5, bookingCode);
			ResultSet resultSet = booking.executeQuery();
			if (resultSet.next()) {
				logger.info("Success");
				return true;

			} else {
				logger.info("failure");

				return false;
			}
			

		} catch (Exception e) {
			e.printStackTrace();
			logger.fatal("Detail Insertion Failed " + e.getLocalizedMessage());

		}
		return false;
	}


}
