package com.TouristExample.model;

public class PaymentDetails {


	private  int paymentDetailsId;
	private BookingDetails bookingDetails;

	private PaymentModeDetails paymentModeDetails;
	public int getPaymentDetailsId() {
		return paymentDetailsId;
	}
	public void setPaymentDetailsId(int paymentDetailsId) {
		this.paymentDetailsId = paymentDetailsId;
	}
	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}
	public void setBookingDetails(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}
	public PaymentModeDetails getPaymentModeDetails() {
		return paymentModeDetails;
	}
	public void setPaymentModeDetails(PaymentModeDetails paymentModeDetails) {
		this.paymentModeDetails = paymentModeDetails;
	}

	

}
