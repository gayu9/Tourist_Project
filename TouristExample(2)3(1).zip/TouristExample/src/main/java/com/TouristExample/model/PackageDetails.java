package com.TouristExample.model;

public class PackageDetails {

	private int packageId;
	private String packageName;
	private int packageType;
	private float packagePrice;
	private int placeId;

	public int getPackageId() {
		return packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public int getPackageType() {
		return packageType;
	}

	public void setPackageType(int packageType) {
		this.packageType = packageType;
	}

	public float getPackagePrice() {
		return packagePrice;
	}

	public void setPackagePrice(float packagePrice) {
		this.packagePrice = packagePrice;
	}

	

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	

	
	

}
