package com.TouristExample.model;

public class PlaceDetails {



	private int placeId;
	private String placesName;

	

	
	


	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	public String getPlacesName() {
		return placesName;
	}

	public void setPlacesName(String placesName) {
		this.placesName = placesName;
	}

	

	
	
}