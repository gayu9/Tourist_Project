package com.TouristExample.Controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TouristExample.Dao.BookingDetailsDao;
import com.TouristExample.model.BookingDetails;
import com.TouristExample.model.ServiceResponse;

@RestController
@RequestMapping("/api")

public class BookingDetailsController {
	@Autowired
	BookingDetailsDao tourist;
	Logger logger = LogManager.getLogger(BookingDetailsController.class);

	@PostMapping(value = "/bookingdetails", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })
	public ServiceResponse Booking(@RequestBody BookingDetails booking) {

		try {
		boolean result=	tourist.insertBookingDetails(booking.getUserId(), booking.getPlaceId(), booking.getMemberCount(),
					booking.getPaymentDetailsId(), booking.getBookingCode());
		if(result)
		{
			ServiceResponse responseSuccess = new ServiceResponse();
			responseSuccess.setStatusCode(200);
			responseSuccess.setMessage("Booking Details insert Successfully");
			responseSuccess.setDetails(booking);
			logger.info("Success");

			return responseSuccess;

		}else
		{
			ServiceResponse responsefailed = new ServiceResponse();
			responsefailed.setStatusCode(404);
			responsefailed.setMessage("Booking Details insert  failed");
			responsefailed.setDetails(booking);
			logger.info("failure");

			return responsefailed;

		}
			
		} catch (Exception e) {
			logger.fatal("Detail Insertion Failed " + e.getLocalizedMessage());
		}
		return null;
	}


}
