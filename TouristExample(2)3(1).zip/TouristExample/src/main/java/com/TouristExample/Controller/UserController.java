package com.TouristExample.Controller;



import org.springframework.http.MediaType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.TouristExample.Dao.UserDao;
import com.TouristExample.model.ServiceResponse;
import com.TouristExample.model.UserDetails;

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserDao tourist;
	Logger logger = LogManager.getLogger(UserController.class);

	@PostMapping(value = "/newuser", produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = {
			MediaType.APPLICATION_JSON_VALUE })

	public ServiceResponse addUser(@RequestBody UserDetails user) {

		

		try {

			if (String.valueOf(user.getAadharNumber()).length() == 12
					&& String.valueOf(user.getCardNumber()).length() == 16
					&& String.valueOf(user.getPinNumber()).length() == 3) {

				boolean result = tourist.newUser(user.getAadharNumber(), user.getCardNumber(), user.getPinNumber());
				if (result) {
					ServiceResponse responseSuccess = new ServiceResponse();
					responseSuccess.setStatusCode(200);
					responseSuccess.setMessage("User Created Successfully");
					responseSuccess.setDetails(user);
					return responseSuccess;

				} else {
					ServiceResponse responsefailed = new ServiceResponse();
					responsefailed.setStatusCode(404);
					responsefailed.setMessage("User Creation failed");
					responsefailed.setDetails(user);
					
					return responsefailed;

				}
			}
			else
			{
				System.out.println("please enter valid input");
			}
			logger.info("try enter");

		} catch (Exception e) {
			logger.fatal("New User Creation Failed " + e.getLocalizedMessage());
		}
		return null;
	}

	@GetMapping(value = "/olduser", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ServiceResponse GetUserdetails(@RequestParam(value = "aadharNumber") long AadharNumber) {

		UserDetails user = new UserDetails();
		user.setAadharNumber(AadharNumber);
		

		try {

			String result = tourist.oldUser(AadharNumber);
			if (result != null) {
				long Number = Long.parseLong(result);

				if (user.getAadharNumber() == Number) {
					ServiceResponse responseSuccess = new ServiceResponse();
					responseSuccess.setStatusCode(200);
					responseSuccess.setMessage("User validation Successfully");
					responseSuccess.setDetails(user.getAadharNumber());

					logger.info("Success");

					return responseSuccess;
				}

				ServiceResponse responsefailed = new ServiceResponse();
				responsefailed.setStatusCode(406);
				responsefailed.setMessage("User validation failed");
				responsefailed.setDetails(user.getAadharNumber());
				logger.info("failure");

				return responsefailed;

			}

		} catch (Exception e) {
			logger.fatal("User Validation Failed " + e.getLocalizedMessage());
		}
		return null;

	}

	

}