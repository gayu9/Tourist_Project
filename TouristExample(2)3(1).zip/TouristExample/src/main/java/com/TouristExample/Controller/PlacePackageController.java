package com.TouristExample.Controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TouristExample.Dao.PlaceAndPackageDao;
import com.TouristExample.model.ServiceResponse;

@RestController
@RequestMapping("/api")

public class PlacePackageController {
	@Autowired
	PlaceAndPackageDao tourist;
	Logger logger = LogManager.getLogger(PlacePackageController.class);
	
	@GetMapping(value = "/placepackage", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ServiceResponse PlaceAndPackagedetails() {

		try {
			List result = tourist.placeAndPackege();
			

			if (result != null) {
				
				ServiceResponse responseSuccess = new ServiceResponse();
				responseSuccess.setMessage("PlaceAndPackage Details Retrieved Successfully");
				responseSuccess.setStatusCode(200);

				responseSuccess.setDetails(result);
				logger.info("Success");

				return responseSuccess;
			} else {
				ServiceResponse responsefailed = new ServiceResponse();
				responsefailed.setStatusCode(406);
				responsefailed.setMessage("PlaceAndPackage Details Retrieved failed");
				responsefailed.setDetails(result);
				logger.info("failure");

				return responsefailed;
			}


		} catch (Exception e) {
			logger.fatal("Details retrieved  Failed " + e.getLocalizedMessage());
		}
		return null;

	}

}
