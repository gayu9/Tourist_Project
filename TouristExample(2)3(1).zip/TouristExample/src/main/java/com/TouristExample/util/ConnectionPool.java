 package com.TouristExample.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.stereotype.Service;
@Service
public class ConnectionPool {
    
	private static String url;
    private static String username;
    private static String password;
    private static String driver;

  
    private static BasicDataSource dataSource=new BasicDataSource();
    
    public BasicDataSource configure() throws IOException {
         
        try {
            FileInputStream  inputStream = new FileInputStream("C:\\Users\\admin\\Downloads\\TouristExample\\TouristExample\\src\\main\\resources\\application.properties");
            Properties properties=new Properties();
            properties.load(inputStream);
            
            driver=properties.getProperty("spring.datasource.driver-class-name");
            url=properties.getProperty("spring.datasource.url");
            username=properties.getProperty("spring.datasource.username");
            password=properties.getProperty("spring.datasource.password");
           
            
            dataSource.setUrl(url);
            dataSource.setUsername(username);
            dataSource.setPassword(password);
            dataSource.setDriverClassName(driver);
            dataSource.setMinIdle(5); 
            dataSource.setMaxIdle(10);
            dataSource.setMaxTotal(20);
                   } catch (Exception e) {
                	   e.printStackTrace();
        }
		return dataSource;
    }
    public Connection connect() throws SQLException, IOException {
    	
    	Connection connection = null;
    	try {
    		dataSource = configure();
    	connection = dataSource.getConnection(); 
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return connection;
    	} 
   
}
