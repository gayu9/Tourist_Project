package com.coonectionPool.demo;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;


public class DemoPool {
	

	private static String url;
    private static String username;
    private static String password;
    private static String driver;

  
    private static BasicDataSource dataSource=new BasicDataSource();
    
    public BasicDataSource configure() throws IOException {
         
        try {
            FileInputStream  inputStream = new FileInputStream("D:\\Backup\\TouristBooking (3112023)\\TouristBooking\\WEB-INF\\src\\properties\\DataBase.properties");
            Properties properties=new Properties();
            properties.load(inputStream);
            
            //driver=properties.getProperty("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            url=properties.getProperty("Url");
            username=properties.getProperty("Username");
            password=properties.getProperty("Password");
           
            dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            dataSource.setUrl(url);
            dataSource.setUsername(username);
            dataSource.setPassword(password);
            dataSource.setMinIdle(5);
            dataSource.setMaxIdle(10);
            dataSource.setMaxTotal(20);
                   } catch (Exception e) {
                	   e.printStackTrace();
        }
		return dataSource;
    }
    
    public void getSourceInsert(String query) throws SQLException {
        Connection connection = null;
        Statement statement = null;
        try {
            dataSource =new DemoPool().configure();
            connection = dataSource.getConnection();
            System.out.println("connection successfully");
            statement=connection.createStatement();
            statement.execute(query);
            System.out.println("insert quary was executed");
            
        } 
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            statement.close();
            connection.close();
        }
    }
public ResultSet getSourceSelect(String query) throws SQLException {
    Connection connection = null;
    Statement statement = null;
    ResultSet resultset=null;
    try {
        dataSource =new DemoPool().configure();
        connection = dataSource.getConnection();
        statement=connection.createStatement();
        resultset=statement.executeQuery(query);
        System.out.println("select query was executed");
        
    } 
    catch(Exception e){
        e.printStackTrace();
    }
    finally {
        resultset.close();
        statement.close();
        connection.close();
    }
    return resultset;
}
}
