package com.ApiIntegration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ApiIntegrationOperations {

	public void placePackage() throws JSONException {
		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpGet getRequest = new HttpGet("http://localhost:8090/TouristExample/api/placepackage");
			getRequest.addHeader("accept", "application/json");

			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			String output=br.readLine();
			
			JSONObject json=json=new JSONObject(output);
            System.out.println(json);
            
            JSONArray arr = (JSONArray) json.get("details");
            
            for (int i = 0; i < arr.length(); i++) {
			JSONObject jsonObject = arr.getJSONObject(i);
			
			System.out.println(jsonObject.get("placeName"));
			}
     
       System.out.println(json.getInt("statusCode"));
       System.out.println(json.getInt(""));

       
           
         
			
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String newUser() {
		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost postRequest = new HttpPost("http://localhost:8090/TouristExample/api/newuser");

			StringEntity input = new StringEntity(
					"{\"aadharNumber\":242424243434,\"cardNumber\":2424242424243434,\"pinNumber\":343}");
			input.setContentType("application/json");

			postRequest.setEntity(input);

			HttpResponse response = httpClient.execute(postRequest);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;
	}

	public String oldUser() {
		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpGet getRequest = new HttpGet("http://localhost:8090/TouristExample/api/olduser?aadharNumber=123456789012");
			getRequest.addHeader("accept", "application/json");
			getRequest.addHeader("Authorization","" );

			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			System.out.println("Output from Server .... \n");
              String output=br.readLine();
			
			JSONObject json=json=new JSONObject(output);
            System.out.println(json);
            System.out.println(json.getLong("details"));
            long Aadhar=json.getLong("details");
            System.out.println(Aadhar);
            
//            JSONArray arr = (JSONArray) json.get("details");
//            System.out.println(arr.getString(0));
//            
//            for (int i = 0; i < arr.length(); i++) {
//			JSONObject jsonObject = arr.getJSONObject(i);
//			
//			System.out.println(jsonObject.get("details"));
			

			return output;

		} catch (Exception e) {
			e.printStackTrace();

		}
		return null;
	}
	public String bookingDetails()
	{
		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost postRequest = new HttpPost("http://localhost:8090/TouristExample/api/bookingdetails");

			StringEntity input = new StringEntity(
					"{\"memberCount\":4,\"bookingCode\":2424,\"userId\":110,\"placeId\":403,\"paymentDetailsId\":1002}");
			input.setContentType("application/json");

			postRequest.setEntity(input);

			HttpResponse response = httpClient.execute(postRequest);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) throws JSONException 
	{

		ApiIntegrationOperations api = new ApiIntegrationOperations();
		//api.placePackage();
		//api.newUser();
		api.oldUser();
	//	api.bookingDetails();

	}
}
